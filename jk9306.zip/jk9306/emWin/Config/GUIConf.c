/*********************************************************************
*                SEGGER Microcontroller GmbH & Co. KG                *
*        Solutions for real time microcontroller applications        *
**********************************************************************
*                                                                    *
*        (c) 1996 - 2012  SEGGER Microcontroller GmbH & Co. KG       *
*                                                                    *
*        Internet: www.segger.com    Support:  support@segger.com    *
*                                                                    *
**********************************************************************

** emWin V5.16 - Graphical user interface for embedded applications **
emWin is protected by international copyright laws.   Knowledge of the
source code may not be used to write a similar product.  This file may
only be used in accordance with a license and should not be re-
distributed in any way. We appreciate your understanding and fairness.
----------------------------------------------------------------------
File        : GUIConf.c
Purpose     : Display controller initialization
---------------------------END-OF-HEADER------------------------------
*/

#include "..\emWin\Header\GUI.h"
//#include "drv_glcd.h"
#include "LCD/lpc177x_8x_lcd.h"
#include "..\User\EX_SDRAM\EX_SDRAM.h"
/*********************************************************************
*
*       Defines
*
**********************************************************************
*/
//
// Define the available number of bytes available for the GUI
//
#define GUI_NUMBYTES  (1024*1024)*12  // x MByte
//
// Define the average block size
//
#define GUI_BLOCKSIZE (0x128)

/* the addr by manual , be careful cal ,now space 2M byte to LCD memory*/
#define LCD_GUI_RAM_BASE  ((uint32_t)(LCD_VRAM_BASE_ADDR+(1024*1024*2)))

/*********************************************************************
*
*       Public code
*
**********************************************************************
*/
/*********************************************************************
*
*       GUI_X_Config
*
* Purpose:
*   Called during the initialization process in order to set up the
*   available memory for the GUI.
*/
void GUI_X_Config(void) {
  //
  // Assign memory to emWin
  //
  GUI_ALLOC_AssignMemory((void *)LCD_GUI_RAM_BASE, GUI_NUMBYTES);
  GUI_ALLOC_SetAvBlockSize(GUI_BLOCKSIZE);
  //
  // Set default font
  //
  GUI_SetDefaultFont(GUI_FONT_D60X80);
}

/*************************** End of file ****************************/
